require 'sinatra'
require './config'

get '/' do
    'hola mundo'
end